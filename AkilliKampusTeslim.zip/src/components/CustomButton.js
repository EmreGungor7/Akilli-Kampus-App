// CustomButton.js dosyası oluşturuldu.
import React from 'react';
import { View, Text } from 'react-native';

export default function CustomButton () { return (<View><Text>CustomButton.js</Text></View>); }