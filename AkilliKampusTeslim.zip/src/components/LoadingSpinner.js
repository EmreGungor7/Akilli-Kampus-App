// LoadingSpinner.js dosyası oluşturuldu.
import React from 'react';
import { View, Text } from 'react-native';

export default function LoadingSpinner () { return (<View><Text>LoadingSpinner.js</Text></View>); }