// AdminDashboard.js dosyası oluşturuldu.
import React from 'react';
import { View, Text } from 'react-native';

export default function AdminDashboard () { return (<View><Text>AdminDashboard.js</Text></View>); }